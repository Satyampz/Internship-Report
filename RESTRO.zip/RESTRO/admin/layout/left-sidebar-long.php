<div class="row">
			
			<div class="col s2 left-sidebar" id="left-sidebar">

				<div class="row">
					<div class="col">
						<h4 class="heading-name">Restro</h4>
					</div>
				</div>
				<ul class="nav nav-sidebar list-group">
				    <li class="list-group-item active"><a href="food-list.php">Foods </a></li>
				    <li class="list-group-item"><a href="category-list.php">Category</a></li>
				    <li class="list-group-item"><a href="order-list.php">Orders</a></li>
				    <li class="list-group-item modal-trigger" data-target="modal1"><a href="#">About</a></li>
				  </ul>
			</div>