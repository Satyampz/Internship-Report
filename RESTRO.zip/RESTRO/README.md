# RESTRO

A Resturant Management System Project in PHP...

Made by :
1.Mansi Mankar
2.Sakshi More
3.Satyam Zope
4.Rushikesh Malve

TE GES R.H. Sapat College Of Engineering ,Nashik

Internship project at NetLeap IT Training and Solutions



How To Run The Project?

To run this project, you must have installed a virtual server i.e XAMPP on your PC (for Windows). This Online Restaurant Management System in PHP with source code is free to download, Use for educational purposes only!

After Starting Apache and MySQL in XAMPP, follow the following steps:

1st Step: Extract file
2nd Step: Copy the main project folder
3rd Step: Paste in xampp/htdocs/

Now Connecting Database

4th Step: Open a browser and go to URL “http://localhost/phpmyadmin/”
5th Step: Then, click on the databases tab
6th Step: Create a database naming “mishtidb” and then click on the import tab
7th Step: Click on browse file and select “mishtidb.sql” file which is inside the “RESTRO” folder
8th Step: Click on go.

After Creating Database,

9th Step: Open a browser and go to URL “http://localhost/RESTRO/”

for admin login : Open a browser and go to URL “http://localhost/RESTRO/admin”